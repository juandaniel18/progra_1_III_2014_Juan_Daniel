public class estadisticas {

    int ganadasJugador1 = 0;
    int perdidasJugador1 = 0;
    int ganadasJugador2 = 0;
    int perdidasJugador2 = 0;

    public int getGanadasJugador1() {
        return ganadasJugador1;
    }

    public void setGanadasJugador1() {
        this.ganadasJugador1++;
    }

    public int getPerdidasJugador1() {
        return perdidasJugador1;
    }

    public void setPerdidasJugador1() {
        this.perdidasJugador1++;
    }

    public int getGanadasJugador2() {
        return ganadasJugador2;
    }

    public void setGanadasJugador2() {
        this.ganadasJugador2++;
    }

    public int getPerdidasJugador2() {
        return perdidasJugador2;
    }

    public void setPerdidasJugador2() {
        this.perdidasJugador2++;
    }

}
